"""Azure Container Apps Sandbox Client Library for Python.

.. note::

   This is a **community preview / beta** release. APIs may change without
   notice in future releases. See the package CHANGELOG for migration notes
   when upgrading.
"""

from azure.containerapps.sandbox._version import VERSION

__version__ = VERSION

from azure.containerapps.sandbox._sandboxgroup_client import SandboxGroupClient
from azure.containerapps.sandbox._sandbox_client import SandboxClient
from azure.containerapps.sandbox._sandboxgroup_mgmt_client import SandboxGroupManagementClient
from azure.containerapps.sandbox._api_version import ApiVersion
from azure.containerapps.sandbox._helpers import (
    DATA_PLANE_BASE,
    DATA_PLANE_SCOPE,
    DATA_PLANE_API_VERSION,
    endpoint_for_region,
    region_from_endpoint,
)
from azure.containerapps.sandbox._models import (
    AddPortRequest,
    AddVolumeMountRequest,
    AutoDeletePolicy,
    AutoSuspendPolicy,
    CpuUsage,
    DirListing,
    DiskImage,
    DiskImageRef,
    DiskImageSpec,
    DiskImageStatus,
    EgressDecisionEntry,
    EgressDecisions,
    EgressHeader,
    EgressHostRule,
    EgressPolicy,
    EgressRule,
    EgressRuleAction,
    EgressRuleMatch,
    ExecResult,
    FileInfo,
    NetworkEgressDecisions,
    NetworkUsage,
    PortAuthConfig,
    PortAuthEntraId,
    PublicDiskImage,
    RegistryCredentials,
    ResourceUsage,
    Sandbox,
    SandboxGroup,
    LifecyclePolicy,
    SandboxPort,
    SandboxResources,
    SandboxSourcesRef,
    SandboxStats,
    SandboxVolume,
    SecretMetadata,
    SecretValuePeek,
    Snapshot,
    SnapshotGpu,
    SnapshotRef,
    SnapshotResources,
    Volume,
    VolumeUsage,
)

__all__ = [
    "SandboxGroupClient",
    "SandboxClient",
    "SandboxGroupManagementClient",
    "ApiVersion",
    "__version__",
    # Constants / helpers
    "DATA_PLANE_BASE",
    "DATA_PLANE_SCOPE",
    "DATA_PLANE_API_VERSION",
    "endpoint_for_region",
    "region_from_endpoint",
    # Models
    "AddPortRequest",
    "AddVolumeMountRequest",
    "AutoDeletePolicy",
    "AutoSuspendPolicy",
    "CpuUsage",
    "DirListing",
    "DiskImage",
    "DiskImageRef",
    "DiskImageSpec",
    "DiskImageStatus",
    "EgressDecisionEntry",
    "EgressDecisions",
    "EgressHeader",
    "EgressHostRule",
    "EgressPolicy",
    "EgressRule",
    "EgressRuleAction",
    "EgressRuleMatch",
    "ExecResult",
    "FileInfo",
    "NetworkEgressDecisions",
    "NetworkUsage",
    "PortAuthConfig",
    "PortAuthEntraId",
    "PublicDiskImage",
    "RegistryCredentials",
    "ResourceUsage",
    "Sandbox",
    "SandboxGroup",
    "LifecyclePolicy",
    "SandboxPort",
    "SandboxResources",
    "SandboxSourcesRef",
    "SandboxStats",
    "SandboxVolume",
    "SecretMetadata",
    "SecretValuePeek",
    "Snapshot",
    "SnapshotGpu",
    "SnapshotRef",
    "SnapshotResources",
    "Volume",
    "VolumeUsage",
]