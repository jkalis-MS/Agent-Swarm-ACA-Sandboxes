"""Egress policy models — shared between requests and responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class EgressHeader:
    """Header transform for an egress rule action."""

    operation: Literal["Set", "Append", "Remove"] = "Set"
    name: str = ""
    value: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressHeader | None:
        if not d:
            return None
        return cls(
            operation=d.get("operation", "Set"),
            name=d.get("name", ""),
            value=d.get("value"),
        )

    def _to_dict(self) -> dict:
        d: dict = {"operation": self.operation, "name": self.name}
        if self.value is not None:
            d["value"] = self.value
        return d


@dataclass
class EgressRuleMatch:
    """Match conditions for an egress rule."""

    host: str = ""
    path: str | None = None
    methods: list[str] | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressRuleMatch | None:
        if not d:
            return None
        return cls(
            host=d.get("host", ""),
            path=d.get("path"),
            methods=d.get("methods"),
        )

    def _to_dict(self) -> dict:
        d: dict = {"host": self.host}
        if self.path is not None:
            d["path"] = self.path
        if self.methods is not None:
            d["methods"] = self.methods
        return d


@dataclass
class EgressRuleAction:
    """Action for an egress rule (Allow/Deny/Transform/Rewrite)."""

    type: Literal["Allow", "Deny", "Transform", "Rewrite"] = "Allow"
    host: str | None = None
    path: str | None = None
    scheme: str | None = None
    headers: list[EgressHeader] | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressRuleAction | None:
        if not d:
            return None
        raw_headers = d.get("headers")
        headers = (
            [EgressHeader._from_dict(h) for h in raw_headers]
            if raw_headers is not None
            else None
        )
        return cls(
            type=d.get("type", "Allow"),
            host=d.get("host"),
            path=d.get("path"),
            scheme=d.get("scheme"),
            headers=headers,
        )

    def _to_dict(self) -> dict:
        d: dict = {"type": self.type}
        if self.host is not None:
            d["host"] = self.host
        if self.path is not None:
            d["path"] = self.path
        if self.scheme is not None:
            d["scheme"] = self.scheme
        if self.headers is not None:
            d["headers"] = [h._to_dict() for h in self.headers]
        return d


@dataclass
class EgressRule:
    """Advanced egress rule with match conditions and action."""

    name: str | None = None
    match: EgressRuleMatch | None = None
    action: EgressRuleAction | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressRule | None:
        if not d:
            return None
        return cls(
            name=d.get("name"),
            match=EgressRuleMatch._from_dict(d.get("match")),
            action=EgressRuleAction._from_dict(d.get("action")),
        )

    def _to_dict(self) -> dict:
        d: dict = {}
        if self.name is not None:
            d["name"] = self.name
        if self.match is not None:
            d["match"] = self.match._to_dict()
        if self.action is not None:
            d["action"] = self.action._to_dict()
        return d


@dataclass
class EgressHostRule:
    """Simple host-pattern egress rule."""

    pattern: str = ""
    action: Literal["Allow", "Deny"] = "Allow"

    @classmethod
    def _from_dict(cls, d: dict) -> EgressHostRule:
        return cls(pattern=d.get("pattern", ""), action=d.get("action", "Allow"))

    def _to_dict(self) -> dict:
        return {"pattern": self.pattern, "action": self.action}


@dataclass
class EgressPolicy:
    """Egress policy for a sandbox — used for both input and output."""

    default_action: Literal["Allow", "Deny"] = "Allow"
    host_rules: list[EgressHostRule] = field(default_factory=list)
    rules: list[EgressRule] = field(default_factory=list)
    traffic_inspection: Literal["Legacy", "Full", "Partial", "None"] | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressPolicy | None:
        if not d:
            return None
        return cls(
            default_action=d.get("defaultAction", "Allow"),
            host_rules=[EgressHostRule._from_dict(r) for r in d.get("hostRules", [])],
            rules=[EgressRule._from_dict(r) for r in d.get("rules", [])],
            traffic_inspection=d.get("trafficInspection"),
        )

    def _to_dict(self) -> dict:
        d: dict = {"defaultAction": self.default_action}
        if self.host_rules:
            d["hostRules"] = [r._to_dict() for r in self.host_rules]
        if self.rules:
            d["rules"] = [r._to_dict() for r in self.rules]
        if self.traffic_inspection is not None:
            d["trafficInspection"] = self.traffic_inspection
        return d


# ---- Response-only models (frozen) ----


@dataclass(frozen=True)
class EgressDecisionEntry:
    """A single egress decision audit entry."""

    timestamp: str | None = None
    host: str | None = None
    method: str | None = None
    path: str | None = None
    scheme: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressDecisionEntry | None:
        if not d:
            return None
        return cls(
            timestamp=d.get("timestamp"),
            host=d.get("host"),
            method=d.get("method"),
            path=d.get("path"),
            scheme=d.get("scheme"),
        )


@dataclass(frozen=True)
class EgressDecisions:
    """Egress decision audit log for a sandbox."""

    network_egress: "NetworkEgressDecisions | None" = None
    last_updated: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressDecisions | None:
        if not d:
            return None
        from azure.containerapps.sandbox._model_types._stats import (
            NetworkEgressDecisions as _NED,
        )

        return cls(
            network_egress=_NED._from_dict(d.get("networkEgress")),
            last_updated=d.get("lastUpdated"),
        )
