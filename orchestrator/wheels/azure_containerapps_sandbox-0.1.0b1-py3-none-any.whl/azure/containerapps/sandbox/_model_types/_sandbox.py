"""Sandbox core models (response-only)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from azure.containerapps.sandbox._model_types._egress import EgressPolicy
from azure.containerapps.sandbox._model_types._lifecycle import LifecyclePolicy
from azure.containerapps.sandbox._model_types._ports import SandboxPort


@dataclass(frozen=True)
class SandboxResources:
    """CPU and memory allocation for a sandbox."""
    cpu: str = ""
    memory: str = ""

    @classmethod
    def _from_dict(cls, d: dict | None) -> SandboxResources | None:
        if not d:
            return None
        return cls(cpu=d.get("cpu", ""), memory=d.get("memory", ""))


@dataclass(frozen=True)
class DiskImageRef:
    """Reference to a disk image used to create a sandbox."""
    name: str | None = None
    id: str | None = None
    is_public: bool | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> DiskImageRef | None:
        if not d:
            return None
        return cls(name=d.get("name"), id=d.get("id"), is_public=d.get("isPublic"))


@dataclass(frozen=True)
class SnapshotRef:
    """Reference to a snapshot used to create a sandbox."""
    id: str = ""

    @classmethod
    def _from_dict(cls, d: dict | None) -> SnapshotRef | None:
        if not d:
            return None
        return cls(id=d.get("id", ""))


@dataclass(frozen=True)
class SandboxSourcesRef:
    """Source reference for sandbox creation (disk image or snapshot)."""
    disk_image: DiskImageRef | None = None
    snapshot: SnapshotRef | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> SandboxSourcesRef | None:
        if not d:
            return None
        return cls(
            disk_image=DiskImageRef._from_dict(d.get("diskImage")),
            snapshot=SnapshotRef._from_dict(d.get("snapshot")),
        )


@dataclass(frozen=True)
class Sandbox:
    """A sandbox instance returned by get/create operations."""
    id: str = ""
    state: Literal["Running", "Stopped", "Suspended", "Idle",
                    "Resuming", "Stopping", "Creating", "Deleting"] | None = None
    labels: dict[str, str] = field(default_factory=dict)
    vmm_type: str | None = None
    ports: list[SandboxPort] = field(default_factory=list)
    resources: SandboxResources | None = None
    egress_policy: EgressPolicy | None = None
    environment: dict[str, str] = field(default_factory=dict)
    connections: list[str] = field(default_factory=list)
    sandbox_group_id: str | None = None
    lifecycle: LifecyclePolicy | None = None
    sources_ref: SandboxSourcesRef | None = None
    preset_sandbox_type: str | None = None
    hostname: str | None = None
    created_at: str | None = None
    region: str | None = None
    entrypoint: list[str] | None = None
    management_url: str | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> Sandbox:
        return cls(
            id=d.get("id", ""),
            state=d.get("state"),
            labels=d.get("labels", {}),
            vmm_type=d.get("vmmType"),
            ports=[SandboxPort._from_dict(p) for p in d.get("ports", [])],
            resources=SandboxResources._from_dict(d.get("resources")),
            egress_policy=EgressPolicy._from_dict(d.get("egressPolicy")),
            environment=d.get("environment", {}),
            connections=d.get("connections", []),
            sandbox_group_id=d.get("sandboxGroupId"),
            lifecycle=LifecyclePolicy._from_dict(d.get("lifecycle")),
            sources_ref=SandboxSourcesRef._from_dict(d.get("sourcesRef")),
            preset_sandbox_type=d.get("presetSandboxType"),
            hostname=d.get("hostname"),
            created_at=d.get("createdAt"),
            region=d.get("region"),
            entrypoint=d.get("entrypoint"),
            management_url=d.get("managementUrl"),
        )
