"""Volume models."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class VolumeUsage:
    """Volume usage information."""
    used: str | None = None
    available: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> VolumeUsage | None:
        if not d:
            return None
        return cls(used=d.get("used"), available=d.get("available"))


@dataclass(frozen=True)
class Volume:
    """A volume resource."""
    name: str = ""
    type: str | None = None
    labels: dict[str, str] = field(default_factory=dict)
    size: str | None = None
    usage: VolumeUsage | None = None
    is_attached: bool | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> Volume:
        return cls(
            name=d.get("volumeName", d.get("name", "")),
            type=d.get("type"),
            labels=d.get("labels", {}),
            size=d.get("size"),
            usage=VolumeUsage._from_dict(d.get("usage")),
            is_attached=d.get("isAttached"),
        )


# ---- Input models ----


@dataclass
class SandboxVolume:
    """Volume reference for sandbox creation.

    Example::

        vol = SandboxVolume(volume_name="my-vol", mountpoint="/data")
    """

    volume_name: str = ""
    mountpoint: str = ""
    read_only: bool | None = None

    def _to_dict(self) -> dict:
        d: dict = {
            "volumeName": self.volume_name,
            "mountpoint": self.mountpoint,
        }
        if self.read_only is not None:
            d["readOnly"] = self.read_only
        return d


@dataclass
class AddVolumeMountRequest:
    """Volume mount request for attaching a volume to a running sandbox.

    Example::

        mount = AddVolumeMountRequest(volume_name="my-volume", mountpoint="/data")
        sandbox.add_volume_mount(mount)
    """

    volume_name: str = ""
    mountpoint: str = ""

    def _to_dict(self) -> dict:
        return {
            "volumeMount": {
                "volumeName": self.volume_name,
                "mountpoint": self.mountpoint,
            }
        }
