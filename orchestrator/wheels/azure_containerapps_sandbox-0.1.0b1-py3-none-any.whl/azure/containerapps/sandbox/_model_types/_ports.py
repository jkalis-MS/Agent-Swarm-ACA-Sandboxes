"""Port models — auth config is shared (input+output), port views differ."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


# ---- Shared models (input + output) ----


@dataclass
class PortAuthEntraId:
    """Entra ID authentication config for a port."""

    enabled: bool = False
    emails: list[str] = field(default_factory=list)

    @classmethod
    def _from_dict(cls, d: dict | None) -> PortAuthEntraId | None:
        if not d:
            return None
        return cls(enabled=d.get("enabled", False), emails=d.get("emails", []))

    def _to_dict(self) -> dict:
        return {"enabled": self.enabled, "emails": self.emails}


@dataclass
class PortAuthConfig:
    """Authentication configuration for a sandbox port.

    Use ``anonymous=True`` for unauthenticated access, or provide
    ``entra_id`` for Entra ID-based access control.

    :raises ValueError: If both ``anonymous`` and ``entra_id`` are set.
    """

    anonymous: bool | None = None
    entra_id: PortAuthEntraId | None = None

    def __post_init__(self) -> None:
        if self.anonymous and self.entra_id is not None:
            raise ValueError("Cannot set both anonymous=True and entra_id")

    @classmethod
    def _from_dict(cls, d: dict | None) -> PortAuthConfig | None:
        if not d:
            return None
        return cls(
            anonymous=d.get("anonymous"),
            entra_id=PortAuthEntraId._from_dict(d.get("entraId")),
        )

    def _to_dict(self) -> dict:
        d: dict = {}
        if self.anonymous is not None:
            d["anonymous"] = self.anonymous
        if self.entra_id is not None:
            d["entraId"] = self.entra_id._to_dict()
        return d


# ---- Response-only model (frozen) ----


@dataclass(frozen=True)
class SandboxPort:
    """A port exposed by a sandbox (response model)."""

    port: int = 0
    host_port: int | None = None
    protocol: Literal["Http", "Http2"] | None = None
    url: str | None = None
    auth: PortAuthConfig | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> SandboxPort:
        return cls(
            port=d.get("port", 0),
            host_port=d.get("hostPort"),
            protocol=d.get("protocol"),
            url=d.get("url"),
            auth=PortAuthConfig._from_dict(d.get("auth")),
        )


# ---- Input-only model ----


@dataclass
class AddPortRequest:
    """Port specification for creating or updating ports.

    Example::

        ports = [
            AddPortRequest(port=8080, auth=PortAuthConfig(anonymous=True)),
            AddPortRequest(port=3000, protocol="Http2"),
        ]
        sandbox.update_ports(ports)
    """

    port: int = 0
    auth: PortAuthConfig | None = None
    protocol: Literal["Http", "Http2"] | None = None
    activation_mode: Literal["Manual", "OnDemand"] | None = None

    def _to_dict(self) -> dict:
        d: dict = {"port": self.port}
        if self.auth is not None:
            d["auth"] = self.auth._to_dict()
        if self.protocol is not None:
            d["protocol"] = self.protocol
        if self.activation_mode is not None:
            d["activationMode"] = self.activation_mode
        return d
